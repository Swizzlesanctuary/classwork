
//1
function checkVotingRight(age) {
  if (age < 18) {
    console.log("You cannot vote.");
  } else {
    console.log("You can vote.");
  }
}

checkVotingRight(16);
checkVotingRight(20);






//2


function checkPasswordStrength(password) {
  if (/^\d+$/.test(password)) {
    console.log("Invalid: password cannot consist only of numbers.");
    return;
  }

  const length = password.length;

  if (length < 3) {
    console.log("Invalid: password is too short.");
  } else if (length >= 3 && length < 6) {
    console.log("Weak password.");
  } else if (length >= 6 && length < 8) {
    console.log("Acceptable password.");
  } else if (length >= 8 && length <= 16) {
    console.log("Strong password.");
  } else {
    console.log("Invalid: password is too long.");
  }
}

checkPasswordStrength("pass");
checkPasswordStrength("Password9!jew");
checkPasswordStrength("1120");



//3

function factorialCalculator(number) {
  if (number < 0) {
    console.log("Factorial is not defined for negative numbers.");
    return;
  }

  let factorial = 1;

  for (let i = 1; i <= number; i++) {
    factorial *= i;
  }

  console.log(`The factorial of ${number} is ${factorial}`);
}


factorialCalculator(5);
factorialCalculator(-1);
factorialCalculator(1092);



//4

function capitalizeFirstLetter(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

console.log(capitalizeFirstLetter("hello"));          
        

//5

function blankStringChecker(str) {
  if (str === "") {
    console.log("This string is blank.");
  } else {
    console.log("This string is not blank.");
  }
}

console.log(blankStringChecker("")); 
console.log(blankStringChecker("string")); 