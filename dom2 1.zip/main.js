
document.querySelector("h1").style.Color = "blue";
document.querySelector("h2").style.backgroundColor = "blue";
document.querySelector("h2").style.color = "white";
document.querySelector("span").style.fontSize = "200%";

document.querySelector("special").style.backgroundColor = "yellow";
document.querySelector("alert").style.border = "gray 1px solid";